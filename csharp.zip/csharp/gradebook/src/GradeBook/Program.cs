﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, Abhijeet!");

// using System;

// namespace GradeBook
// {
//     class Program{
//         static void Main(string[] args){
//             Console.WriteLine("Hello World");
//         }
//     }
// }